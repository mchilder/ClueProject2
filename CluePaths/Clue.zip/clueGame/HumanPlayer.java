package clueGame;

public class HumanPlayer extends Player {

}
