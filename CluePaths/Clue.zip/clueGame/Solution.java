package clueGame;

public class Solution {
	public String room;
	public String weapon;
	public String person;
}
