package clueGame;

import java.util.List;

public class ComputerPlayer extends Player {
	
}
