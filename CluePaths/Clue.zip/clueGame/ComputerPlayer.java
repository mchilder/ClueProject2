package clueGame;

public class ComputerPlayer extends Player {

}
