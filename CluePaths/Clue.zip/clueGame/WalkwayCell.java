package clueGame;

public class WalkwayCell extends BoardCell {
  public boolean isWalkway() {
    return true;
  }
  
  //public void draw() {}
}
