package clueGame;

import java.util.List;

public abstract class Player {
	public String name;
	public String color;
	public int StartingLocation;
	public List<Card> myCards;
}
